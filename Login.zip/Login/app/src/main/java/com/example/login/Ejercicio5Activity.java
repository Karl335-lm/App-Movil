package com.example.login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView;

public class Ejercicio5Activity extends AppCompatActivity {


    ListView listNombres;
    TextView txtResultado;
    Button btnCurso1, btnCurso2, btnVaciar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ejercicio5);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        listNombres = findViewById(R.id.listNombres);
        txtResultado = findViewById(R.id.txtResultado);
        btnCurso1 = findViewById(R.id.btnCurso1);
        btnCurso2 = findViewById(R.id.btnCurso2);
        btnVaciar = findViewById(R.id.btnVaciar);

        // Evento al hacer clic en un nombre
        listNombres.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String seleccionado = adapterView.getItemAtPosition(i).toString();
                txtResultado.setText(seleccionado);
            }
        });

        // Botón Curso 1
        btnCurso1.setOnClickListener(v -> {
            String[] curso1 = {"Juan", "María", "Luis"};
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, curso1);
            listNombres.setAdapter(adapter);
        });

        // Botón Curso 2
        btnCurso2.setOnClickListener(v -> {
            String[] curso2 = {"Ana", "Marta", "Jose"};
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, curso2);
            listNombres.setAdapter(adapter);
        });

        // Botón Vaciar
        btnVaciar.setOnClickListener(v -> {
            txtResultado.setText("");
        });
    }

    }
