package com.example.login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

public class Ejercicio3Activity extends AppCompatActivity {


    private ListView lstColores;
    private TextView lblResultado;
    private int selectedPosition = -1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ejercicio3);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Configurar ListView con los colores
        ListView lstColores = findViewById(R.id.lstColores);
        String[] colores = {"Rojo", "Verde", "Azul"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_single_choice,
                colores
        );
        lstColores.setAdapter(adapter);

        // Configurar botón y resultado
        Button btnAceptar = findViewById(R.id.btnAceptar);
        TextView lblResultado = findViewById(R.id.lblResultado);

        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int posicion = lstColores.getCheckedItemPosition();
                if (posicion == ListView.INVALID_POSITION) {
                    lblResultado.setText("No hay un color seleccionado.");
                } else {
                    String colorSeleccionado = colores[posicion];
                    lblResultado.setText("El color seleccionado es: " + colorSeleccionado);
                }
            }
        });
    }
    }
