package com.example.login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ToggleButton;
import android.widget.Button;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

public class Ejercicio7Activity extends AppCompatActivity {

    private EditText txtPrecioBase;
    private ToggleButton tbtnInstalacion, tbtnFormacion, tbtnAlimentacionBD;
    private TextView lblTotal;
    private TextView lblPrecioInstalacion, lblPrecioFormacion, lblPrecioAlimentacionBD;
    private Button btnCalcular;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ejercicio7);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtPrecioBase = findViewById(R.id.txtPrecioBase);
        tbtnInstalacion = findViewById(R.id.tbtnInstalacion);
        tbtnFormacion = findViewById(R.id.tbtnFormacion);
        tbtnAlimentacionBD = findViewById(R.id.tbtnAlimentacionBD);
        lblTotal = findViewById(R.id.lblTotal);
        lblPrecioInstalacion = findViewById(R.id.lblPrecioInstalacion);
        lblPrecioFormacion = findViewById(R.id.lblPrecioFormacion);
        lblPrecioAlimentacionBD = findViewById(R.id.lblPrecioAlimentacionBD);
        btnCalcular = findViewById(R.id.btnCalcular);

        tbtnInstalacion.setChecked(true); // seleccionado por defecto

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String precioBaseStr = txtPrecioBase.getText().toString().trim();

                if (precioBaseStr.isEmpty()) {
                    txtPrecioBase.setError("Ingresa un precio base");
                    return;
                }

                try {
                    double precioBase = Double.parseDouble(precioBaseStr);
                    double precioInstal = Double.parseDouble(lblPrecioInstalacion.getText().toString());
                    double precioFor = Double.parseDouble(lblPrecioFormacion.getText().toString());
                    double precioAli = Double.parseDouble(lblPrecioAlimentacionBD.getText().toString());

                    double total = precioBase;

                    if (tbtnInstalacion.isChecked()) total += precioInstal;
                    if (tbtnFormacion.isChecked()) total += precioFor;
                    if (tbtnAlimentacionBD.isChecked()) total += precioAli;

                    lblTotal.setText(String.format("%.2f $", total));

                } catch (NumberFormatException e) {
                    txtPrecioBase.setError("Número inválido");
                }
            }
        });
    }
}