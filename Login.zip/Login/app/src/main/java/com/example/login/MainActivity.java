package com.example.login;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        emailEditText = findViewById(R.id.editTextText);
        passwordEditText = findViewById(R.id.editTextTextPassword);

        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener valores de los campos
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString();

                // Validar credenciales
                if (validateCredentials(email, password)) {
                    // Credenciales válidas - redirigir
                    Intent intent = new Intent(MainActivity.this, VistaEjercicios.class);
                    startActivity(intent);
                }
            }
        });
    }

    private boolean validateCredentials(String email, String password) {
        boolean isEmailValid = isValidEmail(email);
        boolean isPasswordValid = password.equals("tap*2025");

        if (!isEmailValid && !isPasswordValid) {
            Toast.makeText(this, "Correo inválido y contraseña incorrecta", Toast.LENGTH_LONG).show();
            return false;
        } else if (!isEmailValid) {
            Toast.makeText(this, "Formato de correo electrónico inválido", Toast.LENGTH_LONG).show();
            return false;
        } else if (!isPasswordValid) {
            Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

    private boolean isValidEmail(String email) {
        return !email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
}