package com.example.login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Ejercicio6Activity extends AppCompatActivity {


    private Spinner spinnerNumeros;
    private Button btnPares, btnImpares, btnVaciar;
    private TextView txtResultado;
    private ArrayList<String> numeros;
    private ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ejercicio6);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setContentView(R.layout.activity_ejercicio6); // Asegúrate de que este sea el nombre correcto del XML

        // Vincular vistas
        spinnerNumeros = findViewById(R.id.spinnerNumeros);
        btnPares = findViewById(R.id.btnPares);
        btnImpares = findViewById(R.id.btnImpares);
        btnVaciar = findViewById(R.id.btnVaciar);
        txtResultado = findViewById(R.id.txtResultado);

        // Inicializar lista y adaptador
        numeros = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, numeros);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerNumeros.setAdapter(adapter);

        // Botón pares
        btnPares.setOnClickListener(v -> {
            numeros.clear();
            for (int i = 0; i < 10; i += 2) {
                numeros.add("N° " + i);
            }
            adapter.notifyDataSetChanged();
        });

        // Botón impares
        btnImpares.setOnClickListener(v -> {
            numeros.clear();
            for (int i = 1; i < 10; i += 2) {
                numeros.add("N° " + i);
            }
            adapter.notifyDataSetChanged();
        });

        // Botón vaciar
        btnVaciar.setOnClickListener(v -> {
            numeros.clear();
            adapter.notifyDataSetChanged();
            txtResultado.setText("");
        });

        // Spinner selecciona número
        spinnerNumeros.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                txtResultado.setText(numeros.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                txtResultado.setText("");
            }
        });

}
}