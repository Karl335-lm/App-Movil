package com.example.login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import android.widget.NumberPicker;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
public class Ejercicio9Activity extends AppCompatActivity {
    private NumberPicker numberPicker;
    private TextView lblValor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ejercicio9);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        setTitle("Ejercicio 9");

        numberPicker = findViewById(R.id.numberPicker);
        lblValor = findViewById(R.id.lblValor);

        numberPicker.setMinValue(0);
        numberPicker.setMaxValue(10);

        numberPicker.setOnValueChangedListener((picker, oldVal, newVal) -> {
            lblValor.setText("El valor es: " + newVal);
        });
    }
    }
