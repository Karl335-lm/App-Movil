package com.example.login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Ejercicio8Activity extends AppCompatActivity {
    private SeekBar seekBar;
    private TextView lblValor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ejercicio8);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        seekBar = findViewById(R.id.seekBar);
        lblValor = findViewById(R.id.lblValor);

        // Configurar límites del SeekBar (100 a 500)
        seekBar.setMax(400); // Diferencia entre max y min
        seekBar.setProgress(300); // Equivale a valor 400 porque 100 + 300 = 400

        // Mostrar el valor inicial
        lblValor.setText("El valor es: " + (seekBar.getProgress() + 100));

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                lblValor.setText("El valor es: " + (progress + 100));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No necesario aquí
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // No necesario aquí
            }
        });

}
}