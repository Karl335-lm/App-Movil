package com.example.login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class VistaEjercicios extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vista_ejercicios);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



        // Referencias a los botones
        Button btnEj1 = findViewById(R.id.button2);
        Button btnEj2 = findViewById(R.id.button3);
        Button btnEj3 = findViewById(R.id.button4);
        Button btnEj4 = findViewById(R.id.button5);
        Button btnEj5 = findViewById(R.id.button6);
        Button btnEj6 = findViewById(R.id.button7);
        Button btnEj7 = findViewById(R.id.button8);
        Button btnEj8 = findViewById(R.id.button9);
        Button btnEj9 = findViewById(R.id.button10);
        Button btnEj10 = findViewById(R.id.button11);

        // Configurar listeners para cada botón
        btnEj1.setOnClickListener(v -> abrirActividad(Ejercicio1Activity.class));
        btnEj2.setOnClickListener(v -> abrirActividad(Ejercicio2Activity.class));
        btnEj3.setOnClickListener(v -> abrirActividad(Ejercicio3Activity.class));
        btnEj4.setOnClickListener(v -> abrirActividad(Ejercicio4Activity.class));
        btnEj5.setOnClickListener(v -> abrirActividad(Ejercicio5Activity.class));

        btnEj6.setOnClickListener(v -> abrirActividad(Ejercicio6Activity.class));
        btnEj7.setOnClickListener(v -> abrirActividad(Ejercicio7Activity.class));
        btnEj8.setOnClickListener(v -> abrirActividad(Ejercicio8Activity.class));
        btnEj9.setOnClickListener(v -> abrirActividad(Ejercicio9Activity.class));
        btnEj10.setOnClickListener(v -> abrirActividad(Ejercicio10Activity.class));
    }

    private void abrirActividad(Class<?> actividad) {
        Intent intent = new Intent(this, actividad);
        startActivity(intent);
    }

    }
