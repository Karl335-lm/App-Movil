package com.example.login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class Ejercicio1Activity extends AppCompatActivity {

    private CheckBox chkPerro, chkRaton, chkGato;
    private Button btnAceptar;
    private TextView lblResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ejercicio1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        chkPerro = findViewById(R.id.chkPerro);
        chkRaton = findViewById(R.id.chkRaton);
        chkGato = findViewById(R.id.chkGato);
        btnAceptar = findViewById(R.id.btnAceptar);
        lblResultado = findViewById(R.id.lblResultado);

        // Configurar listener para el botón
        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarAnimalesSeleccionados();
            }
        });
    }

    private void mostrarAnimalesSeleccionados() {
        StringBuilder animales = new StringBuilder("Animales elegidos: ");

        if (chkPerro.isChecked()) {
            animales.append("Perro ");
        }
        if (chkRaton.isChecked()) {
            animales.append("Raton ");
        }
        if (chkGato.isChecked()) {
            animales.append("Gato ");
        }

        lblResultado.setText(animales.toString());
    }


    }
