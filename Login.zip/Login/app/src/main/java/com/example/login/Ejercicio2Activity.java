package com.example.login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class Ejercicio2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ejercicio2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Referencias a los componentes
        RadioButton optRojo = findViewById(R.id.optRojo);
        RadioButton optVerde = findViewById(R.id.optVerde);
        RadioButton optAzul = findViewById(R.id.optAzul);
        Button btnAceptar = findViewById(R.id.btnAceptar);
        TextView lblResultado = findViewById(R.id.lblResultado);

        // Listener del botón
        btnAceptar.setOnClickListener(v -> {
            String mensaje = "Color elegido: ";

            if (optRojo.isChecked()) {
                mensaje += "Rojo";
            } else if (optVerde.isChecked()) {
                mensaje += "Verde";
            } else if (optAzul.isChecked()) {
                mensaje += "Azul";
            }

            lblResultado.setText(mensaje);
        });
    }

    }
